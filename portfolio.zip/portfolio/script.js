// JS optional functionality
console.log("Portfolio loaded");
